package com.appname.tutorial.AppName;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppNameApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppNameApplication.class, args);
	}

}
