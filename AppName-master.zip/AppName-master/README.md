# AppName - Simplified Building Web Application using Springboot + Angular + Maven

[![Build Status](https://travis-ci.com/ihappyk/AppName.svg?branch=master)](https://travis-ci.com/ihappyk/AppName)

[![Hang out with the team](https://img.shields.io/badge/Ask%20me-anything-1abc9c.svg)](https://dzone.com/articles/simplified-building-web-application-using-spring-b)

DZone Article Source Code
